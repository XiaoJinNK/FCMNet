# FCMNet

Prerequisites

	Ubuntu 18
	
	pytorch 1.7
	
	CUDA 10.0
	
	python 3.7
	
	
Train/Test

 train
 
 set the param '--phase' as "train" and '--param' as 'True'(loading checkpoint) or 'False'(do not load checkpoint) in demo.py.
 
 python demo.py
 
 test
 
 set the param '--phase' as "test" and '--param' as 'True' in demo.py.
 
 python demo.py
 
